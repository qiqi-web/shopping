window.onload = function() {
    var regtel = /^1[3|4|5|7|8]\d{9}$/;
    var tel = document.querySelector('#tel');
    regexp(tel, regtel); //手机号码验证

    var regqq = /^[1-9]\d{4,}$/;
    var qq = document.querySelector('#qq');
    regexp(qq, regqq); //qq验证

    // 汉字
    var regnc = /^[\u4e00-\u9fa5]{2,8}$/;
    var nc = document.querySelector('#nc')
    regexp(nc, regnc); //昵称验证

    var regmsg = /^\d{6}$/;
    var msg = document.querySelector('#msg');
    regexp(msg, regmsg); //验证码验证

    var regpwd = /^[a-zA-Z0-9_-]{6,16}$/;
    var pwd = document.querySelector('#pwd');
    regexp(pwd, regpwd); //密码验证

    var surepwd = document.querySelector('#surepwd');


    function regexp(ele, reg) {
        ele.onblur = function() {
            if (reg.test(this.value)) {
                this.nextElementSibling.className = 'success';
                this.nextElementSibling.innerHTML = '<i class = "success_icon"></i>恭喜您输入正确';
            } else {
                this.nextElementSibling.className = 'error';
                this.nextElementSibling.innerHTML = '<i class = "error_icon"></i>格式不正确，请重新输入';
            }
        }
    }

    surepwd.onblur = function() {
        if (this.value === pwd.value) {
            this.nextElementSibling.className = 'success';
            this.nextElementSibling.innerHTML = '<i class = "success_icon"></i>恭喜您输入正确';
        } else {
            this.nextElementSibling.className = 'error';
            this.nextElementSibling.innerHTML = '<i class = "error_icon"></i>两次密码输入不一致 请重新输入';
        }
    }
}